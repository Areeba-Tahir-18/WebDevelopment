let express= require("express");
let express_layout= require("express-ejs-layouts");

let server= express();

server.use(express.static("public"));

server.set("view engine",'ejs');

server.get("/cv", (req,res) => {
    res.render("Assignment1");
});

server.get("/test", (req,res) => {
    res.render("test");
});

server.listen(8000);
