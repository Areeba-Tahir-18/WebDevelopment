// Load required modules
const express = require("express");
const ejs_layouts = require("express-ejs-layouts");
const session = require("express-session");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
require("dotenv").config();

// Route files
const router1 = require('./routes/index');
const { router: authRoutes } = require('./routes/auth');
const cartRoutes = require('./routes/cart');
const orderRoutes = require('./routes/order');
const adminRoutes = require("./routes/admin");
const complaintRoutes = require('./routes/complaint');

// Initialize Express app
const app = express();
const port = process.env.PORT || 3000;

// Set up session
app.use(session({
  secret: process.env.SESSION_SECRET || 'defaultSecret',
  resave: false,
  saveUninitialized: true
}));

mongoose.connect('mongodb://localhost:27017/henbun', {
  useNewUrlParser: true
});


// Make session available in views
app.use((req, res, next) => {
  res.locals.session = req.session;
  next();
});

// Set static folder
app.use(express.static("public"));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(ejs_layouts);

// Set view engine
app.set('view engine', 'ejs');

// Register routes
app.use('/', router1);
app.use('/auth', authRoutes);
app.use('/cart', cartRoutes);
app.use('/', orderRoutes);
app.use('/admin', adminRoutes);
app.use(complaintRoutes);  // Complaint routes (must come after session setup)

mongoose.connect('mongodb://localhost:27017/henbun', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log("✅ Connected to MongoDB");
})
.catch((err) => {
  console.error("❌ MongoDB connection error:", err);
});


// Start server
app.listen(port, () => {
  console.log(`✅ Server is running at http://localhost:${port}`);
});
