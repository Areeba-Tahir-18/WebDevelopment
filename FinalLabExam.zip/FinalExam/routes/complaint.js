// routes/complaint.js
const express = require('express');
const router = express.Router();
const Complaint = require('../models/Complaint');
const { isAuthenticated, isAdmin } = require('../routes/auth');

// Show complaint form
router.get('/complaint', isAuthenticated, (req, res) => {
    res.render('complaint_form');
});

// Submit complaint
router.post('/complaint', isAuthenticated, async (req, res) => {
    const { orderId, message } = req.body;
    try {
        await Complaint.create({
            userId: req.session.user._id,  // ✅ use session
            orderId,
            message
        });
        res.redirect('/complaints');
    } catch (err) {
        res.status(500).send('Error submitting complaint.');
    }
});

// User view: own complaints
router.get('/complaints', isAuthenticated, async (req, res) => {
    const complaints = await Complaint.find({ userId: req.session.user._id }).populate('orderId');
    res.render('complaint_list', { complaints });
});

// Admin view: all complaints
router.get('/admin/complaints', isAuthenticated, isAdmin, async (req, res) => {
    const complaints = await Complaint.find({}).populate('userId').populate('orderId');
    res.render('admin_complaints', { complaints });
});

module.exports = router;
