const mongoose = require("mongoose");
const Product = require("./models/Products");

mongoose
  .connect("mongodb://127.0.0.1:27017/henbun")
  .then(async () => {
    await Product.insertMany([
      {
        title: "Satin Floral Maxi Dress",
        price: 3499,
        description:
          "1 LEG, 1 THIGH, 1 BREAST, 1 WING, 1 BUN, FRIES, 1 LARGE GARLIC DIP, 500 ML DRINK",
        image: "/images/deal1.webp",
      },
      {
        title: "Linen Shirt Dress",
        price: 2799,
        description:
          "2 LEGS, 2 THIGHS, 2 BREASTS, 2 WINGS, 2 BUNS, FRIES, 2 LARGE GARLIC DIPS, 1.5 LTR DRINK",
        image: "/images/deal2.webp",
      },
      {
        title: "Silk Wrap Midi Dress",
        price: 3999,
        description:
          "4 LEGS, 4 THIGHS, 4 BREASTS, 4 WINGS, 4 BUNS, FRIES, 4 LARGE GARLIC DIPS",
        image: "/images/deal3.webp",
      },
      {
        title: "Chiffon Tiered Midi Dress",
        price: 2999,
        description:
          "4 LEGS, 4 THIGHS, 4 BREASTS, 4 WINGS, 4 BUNS, FRIES, 4 LARGE GARLIC DIPS",
        image: "/images/deal4.webp",
      },
    ]);
    console.log("Products added ");
    process.exit();
  })
  .catch((err) => {
    console.error("Database connection error:", err);
    process.exit(1);
  });
